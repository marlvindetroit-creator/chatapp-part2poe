package scribbler;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static int totalMessagesSent = 0;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        UserLogin authService = new UserLogin();
        
        System.out.println("=========================================");
        System.out.println("   WELCOME TO QUICKCHAT (PROG5121)");
        System.out.println("=========================================");

        // Simulate User Account Registration & Login requirement
        System.out.print("Enter Username to register: ");
        String uname = input.nextLine();
        System.out.print("Enter Password: ");
        String pwd = input.nextLine();
        System.out.print("Enter SA Cell Phone Number (+27...): ");
        String cell = input.nextLine();

        authService.registerUser(uname, pwd, cell, "Student", "User");
        
        System.out.println("\n--- QuickChat Login ---");
        System.out.print("Enter Username: ");
        String loginUname = input.nextLine();
        System.out.print("Enter Password: ");
        String loginPwd = input.nextLine();

        boolean isAuthenticated = authService.loginUser(loginUname, loginPwd);
        System.out.println(authService.returnLoginStatus());

        if (!isAuthenticated) {
            System.out.println("Authentication failed. Terminating QuickChat application.");
            return;
        }

        // Feature display after successful login
        System.out.println("\nWelcome to QuickChat.");
        boolean keepRunning = true;

        while (keepRunning) {
            System.out.println("\n--- MAIN MENU ---");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Please enter your choice (1-3): ");

            String choice = input.nextLine();

            switch (choice) {
                case "1":
                    handleSendMessages(input);
                    break;
                case "2":
                    System.out.println("Coming Soon.");
                    break;
                case "3":
                    keepRunning = false;
                    System.out.println("Thank you for using QuickChat. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please select 1, 2, or 3.");
            }
        }
    }

    private static void handleSendMessages(Scanner input) {
        System.out.print("\nHow many messages would you like to enter? ");
        int count = 0;
        try {
            count = Integer.parseInt(input.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid numeric input. Returning to menu.");
            return;
        }

        List<Message> sessionMessages = new ArrayList<>();

        for (int i = 1; i <= count; i++) {
            System.out.println("\n--- Entering Message " + i + " of " + count + " ---");
            
            System.out.print("Enter Recipient Cell Number (+27...): ");
            String recipient = input.nextLine();

            System.out.print("Enter Message Content (Max 250 chars): ");
            String body = input.nextLine();

            Message msg = new Message(i, recipient, body);

            // Validation Checks
            String lengthCheck = msg.checkMessageLength();
            System.out.println(lengthCheck);
            if (!lengthCheck.equals("Message ready to send.")) {
                System.out.println("Skipping message entry due to validation error.");
                continue;
            }

            String cellCheck = msg.checkRecipientCell();
            System.out.println(cellCheck);
            if (!cellCheck.equals("Cell phone number successfully captured.")) {
                System.out.println("Skipping message entry due to invalid cell number format.");
                continue;
            }

            // Message Action Menu
            System.out.println("\nSelect an action for this message:");
            System.out.println("1 - Send Message");
            System.out.println("2 - Disregard Message");
            System.out.println("3 - Store Message to send later");
            System.out.print("Choice: ");

            int action = 1;
            try {
                action = Integer.parseInt(input.nextLine());
            } catch (Exception e) {
                action = 1;
            }

            String response = msg.sentMessage(action);
            System.out.println(response);

            if (action == 1) {
                totalMessagesSent++;
                sessionMessages.add(msg);
            } else if (action == 3) {
                MessageStorage.storeMessage(msg);
            }
        }

        // Display summary output
        System.out.println("\n=========================================");
        System.out.println("        SENT MESSAGES SUMMARY            ");
        System.out.println("=========================================");
        for (Message msg : sessionMessages) {
            System.out.println(msg.printMessages());
        }
        System.out.println("Total Messages Sent in Session: " + sessionMessages.size());
        System.out.println("Total Messages Sent Overall: " + totalMessagesSent);
    }

    public static int returnTotalMessages() {
        return totalMessagesSent;
    }
}