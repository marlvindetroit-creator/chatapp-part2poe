package scribbler;

import java.util.Random;

/**
 * Represents a chat message within the QuickChat system.
 * Handles validation, ID creation, hash generation, and message state formatting.
 */
public class Message {

    private String messageId;
    private int messageNumber;
    private String recipientCell;
    private String messageBody;
    private String messageHash;
    private int sendStatusOption; // 1: Send, 2: Disregard, 3: Store

    /**
     * Constructor for generating a new Message instance.
     *
     * @param messageNumber Sequential index of the message in current session.
     * @param recipientCell Recipient's phone number.
     * @param messageBody Content of the message.
     */
    public Message(int messageNumber, String recipientCell, String messageBody) {
        this.messageNumber = messageNumber;
        this.recipientCell = recipientCell;
        this.messageBody = messageBody;
        this.messageId = generateMessageID();
        this.messageHash = createMessageHash();
    }

    /**
     * Generates a 10-digit random Message ID.
     */
    private String generateMessageID() {
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            sb.append(random.nextInt(10));
        }
        return sb.toString();
    }

    /**
     * Checks whether the message ID length does not exceed 10 digits.
     */
    public boolean checkMessageID() {
        return this.messageId != null && this.messageId.length() <= 10;
    }

    /**
     * Validates recipient cell number format and length.
     */
    public String checkRecipientCell() {
        if (this.recipientCell == null || this.recipientCell.length() > 13) {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
        
        // Regex checking international code format (e.g., +27...)
        if (this.recipientCell.matches("^\\+\\d{1,3}\\d{8,10}$")) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    /**
     * Validates message body character limit (Max 250 characters).
     */
    public String checkMessageLength() {
        if (this.messageBody.length() <= 250) {
            return "Message ready to send.";
        } else {
            int excess = this.messageBody.length() - 250;
            return "Message exceeds 250 characters by " + excess + "; please reduce the size.";
        }
    }

    /**
     * Constructs the message hash using string manipulation.
     * Format: FIRST_TWO_DIGITS_ID:MESSAGE_NUM:FIRST_WORD_LAST_WORD (All Uppercase)
     */
    public String createMessageHash() {
        String idPrefix = (messageId != null && messageId.length() >= 2) ? messageId.substring(0, 2) : "00";
        
        String cleanText = messageBody.trim().replaceAll("[^a-zA-Z0-9\\s]", "");
        String[] words = cleanText.split("\\s+");
        
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        
        String combinedWords = (firstWord + lastWord).toUpperCase();
        return idPrefix + ":" + messageNumber + ":" + combinedWords;
    }

    /**
     * Sets the status option chosen by the user and returns the associated response string.
     */
    public String sentMessage(int option) {
        this.sendStatusOption = option;
        switch (option) {
            case 1:
                return "Message successfully sent.";
            case 2:
                return "Press 0 to delete the message.";
            case 3:
                return "Message successfully stored.";
            default:
                return "Invalid option selected.";
        }
    }

    /**
     * Formats message details into readable console output format.
     */
    public String printMessages() {
        return "----------------------------------------\n" +
               "Message ID: " + messageId + "\n" +
               "Message Hash: " + messageHash + "\n" +
               "Recipient: " + recipientCell + "\n" +
               "Message: " + messageBody + "\n" +
               "----------------------------------------";
    }

    // JSON String conversion utility method
    public String toJsonString() {
        return "{\n" +
               "  \"messageId\": \"" + messageId + "\",\n" +
               "  \"messageNumber\": " + messageNumber + ",\n" +
               "  \"recipientCell\": \"" + recipientCell + "\",\n" +
               "  \"messageBody\": \"" + escapeJson(messageBody) + "\",\n" +
               "  \"messageHash\": \"" + messageHash + "\"\n" +
               "}";
    }

    private String escapeJson(String text) {
        return text.replace("\"", "\\\"").replace("\n", "\\n");
    }

    // Getters and Setters
    public String getMessageId() { return messageId; }
    public void setMessageId(String messageId) { this.messageId = messageId; this.messageHash = createMessageHash(); }
    public int getMessageNumber() { return messageNumber; }
    public String getRecipientCell() { return recipientCell; }
    public String getMessageBody() { return messageBody; }
    public String getMessageHash() { return messageHash; }
    public int getSendStatusOption() { return sendStatusOption; }
}