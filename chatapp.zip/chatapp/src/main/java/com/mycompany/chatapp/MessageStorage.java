package scribbler;

import java.io.FileWriter;
import java.io.IOException;

/**
 * Service class handling JSON operations for message objects.
 */
public class MessageStorage {

    private static final String FILE_PATH = "stored_messages.json";

    /**
     * Stores a message into a local JSON file format.
     */
    public static boolean storeMessage(Message message) {
        try (FileWriter writer = new FileWriter(FILE_PATH, true)) {
            writer.write(message.toJsonString() + ",\n");
            return true;
        } catch (IOException e) {
            System.err.println("Error saving message to JSON: " + e.getMessage());
            return false;
        }
    }
}